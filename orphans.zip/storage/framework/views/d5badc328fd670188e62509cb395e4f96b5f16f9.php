<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="row">
            <div class="col-md-3">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Orphan Dashboard')); ?>

                </h2>
            </div>
            <div class="col-md-6"></div>
            <div class="col-md-3" style="text-align: right">
               Wallet: <?php echo e(auth()->user()->wallet); ?> $
            </div>
        </div>

     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <h2 style="text-align: center">My Sponsor </h2>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">

                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Image</th>
                        <th scope="col">Start Warranty Date</th>
                        <th scope="col">Warranty Value</th>
                        <th scope="col">Warranty Period</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=1?>
                    <?php $__currentLoopData = $mySponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orphan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row"><?php echo e($i++); ?></th>
                            <td><?php echo e($orphan->name); ?></td>
                            <td><img src="<?php echo e(asset('admin/img'.$orphan->image)); ?>" alt=""></td>
                            <td><?php echo e($orphan->pivot->start_warranty_date); ?></td>
                            <td><?php echo e($orphan->pivot->warranty_value); ?></td>
                            <td><?php echo e($orphan->pivot->warranty_period); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\orphans\resources\views/orphans/orphan-dashboard.blade.php ENDPATH**/ ?>