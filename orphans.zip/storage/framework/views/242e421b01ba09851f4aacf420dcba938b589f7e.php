<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="row">
            <div class="col-md-3">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Sponsor Dashboard')); ?>

                </h2>
            </div>
            <div class="col-md-6"></div>
            <div class="col-md-3" style="text-align: right">
                Wallet: <?php echo e(auth()->user()->wallet); ?> $
            </div>
        </div>

     <?php $__env->endSlot(); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="py-12">
        <h2 style="text-align: center">Add Price</h2>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <form action="<?php echo e(route('add.wallet')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="" class="py-4 text-center form-control">Value</label>
                        <input type="number" class="form-control mb-2"  name="value_pay">
                        <?php $__errorArgs = ['value_pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success form-control">Pay</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <div class="py-12">
        <h2 style="text-align: center">My orphan </h2>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">

                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Image</th>
                            <th scope="col">Start Warranty Date</th>
                            <th scope="col">Warranty Value</th>
                            <th scope="col">Warranty Period</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=1?>
                        <?php $__currentLoopData = $myOrphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orphan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                            <th scope="row"><?php echo e($i++); ?></th>
                            <td><?php echo e($orphan->name); ?></td>
                            <td><img src="<?php echo e(asset('admin/img'.$orphan->image)); ?>" alt=""></td>
                            <td><?php echo e($orphan->pivot->start_warranty_date); ?></td>
                            <td><?php echo e($orphan->pivot->warranty_value); ?></td>
                            <td><?php echo e($orphan->pivot->warranty_period); ?></td>
                                <td><a href="<?php echo e(route('remove.orphan',$orphan->id)); ?>" class="btn btn-danger" >Delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
            </div>
        </div>

    </div>
    <div class="py-12">
        <h2 style="text-align: center">Add orphan </h2>
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <form action="<?php echo e(route('add.orphan')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="" class="py-4 text-center form-control">Orphan</label>
                        <select name="orphan_id" id="" class="form-control">
                            <option value=""></option>
                            <?php $__currentLoopData = $orphans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orphan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($orphan->id); ?>"><?php echo e($orphan->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['orphan_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="" class="py-4 text-center form-control">Warranty Value</label>
                        <input type="number" class="form-control mb-2"  name="warranty_value">
                        <?php $__errorArgs = ['warranty_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="" class="py-4 text-center form-control">Warranty Period</label>
                        <input type="number" class="form-control mb-2"  name="warranty_period">
                        <?php $__errorArgs = ['warranty_period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-success form-control">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\orphans\resources\views/sponsors/sponsor-dashboard.blade.php ENDPATH**/ ?>